import typer

from pa_cli.api.files import FilesClient
from pa_cli.api.webapps import WebappsClient
from pa_cli.cli.utils import get_client, fix_remote_path
from pa_cli.config import Config
from pa_cli.crawler.account_crawler import AccountCrawler
from pa_cli.exceptions import AuthError, NetworkError, NotFoundError, APIError

app = typer.Typer(help="Manage web apps on PythonAnywhere.")


@app.command()
def create(
    domain_name: str = typer.Argument(..., help="Domain name"),
    python_version: str = typer.Option("python312", "--python", "-p", help="Python version"),
):
    """Create a new web app."""
    try:
        account, client = get_client(WebappsClient)
        client.create(account["username"], domain_name, python_version)
        typer.echo(f"Webapp {domain_name} created with {python_version}")
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Not found: {e}", err=True)
        raise typer.Exit(code=1)
    except APIError as e:
        typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(code=1)


@app.command()
def config(
    domain_name: str = typer.Argument(None, help="Domain name (default: {username}.pythonanywhere.com)"),
    source_dir: str = typer.Option(None, "--source-dir", "-s", help="Source directory path"),
    virtualenv: str = typer.Option(None, "--virtualenv", "-v", help="Virtualenv path"),
    python_version: str = typer.Option(None, "--python-version", "-p", help="Python version (e.g. 3.10, 3.11)"),
    working_dir: str = typer.Option(None, "--working-dir", "-w", help="Working directory path"),
):
    """Configure a web app."""
    try:
        account, client = get_client(WebappsClient)
        if domain_name is None:
            domain_name = f"{account['username']}.pythonanywhere.com"
        kwargs = {}
        if source_dir:
            kwargs["source_directory"] = fix_remote_path(source_dir)
        if virtualenv:
            kwargs["virtualenv_path"] = fix_remote_path(virtualenv)
        if python_version:
            kwargs["python_version"] = python_version
        if working_dir:
            kwargs["working_directory"] = fix_remote_path(working_dir)
        if not kwargs:
            typer.echo("Error: No configuration specified. Use --source-dir, --virtualenv, --python-version, or --working-dir.", err=True)
            raise typer.Exit(code=1)
        client.update(account["username"], domain_name, **kwargs)
        typer.echo(f"Webapp {domain_name} configured.")
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Not found: {e}", err=True)
        raise typer.Exit(code=1)
    except APIError as e:
        typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(code=1)


@app.command()
def static(
    domain_name: str = typer.Argument(..., help="Domain name"),
    url: str = typer.Option(..., "--url", help="URL prefix"),
    path: str = typer.Option(..., "--path", help="Directory path"),
):
    """Add a static file mapping."""
    try:
        account, client = get_client(WebappsClient)
        fixed_path = fix_remote_path(path)
        client.add_static_file(account["username"], domain_name, url=url, path=fixed_path)
        typer.echo(f"Static mapping added: {url} -> {fixed_path}")
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Not found: {e}", err=True)
        raise typer.Exit(code=1)
    except APIError as e:
        typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(code=1)


@app.command()
def reload(
    domain_name: str = typer.Argument(..., help="Domain name"),
):
    """Reload a web app."""
    try:
        account, client = get_client(WebappsClient)
        client.reload(account["username"], domain_name)
        typer.echo(f"Webapp {domain_name} reloaded.")
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Not found: {e}", err=True)
        raise typer.Exit(code=1)
    except APIError as e:
        typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(code=1)


@app.command("hits")
def hits(
    domain_name: str = typer.Argument(None, help="Domain name (default: {username}.pythonanywhere.com)"),
):
    """Get web app hit statistics via crawler."""
    try:
        account = Config.load(verbose=True)
        if domain_name is None:
            domain_name = f"{account['username']}.pythonanywhere.com"
        crawler = AccountCrawler()
        crawler.login()
        data = crawler.get_hits(domain_name)
        typer.echo(f"Hit statistics for {domain_name}:")
        for key, value in data.items():
            typer.echo(f"  {key}: {value}")
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Not found: {e}", err=True)
        raise typer.Exit(code=1)


@app.command("reload-crawler")
def reload_crawler(
    domain_name: str = typer.Argument(None, help="Domain name (default: {username}.pythonanywhere.com)"),
):
    """Reload a web app via crawler (alternative to API reload)."""
    try:
        account = Config.load(verbose=True)
        if domain_name is None:
            domain_name = f"{account['username']}.pythonanywhere.com"
        crawler = AccountCrawler()
        crawler.login()
        if crawler.reload_webapp(domain_name):
            typer.echo(f"Webapp {domain_name} reloaded successfully.")
        else:
            typer.echo(f"Failed to reload webapp {domain_name}.", err=True)
            raise typer.Exit(code=1)
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Not found: {e}", err=True)
        raise typer.Exit(code=1)


@app.command()
def delete(
    domain_name: str = typer.Argument(..., help="Domain name"),
    force: bool = typer.Option(False, "-f", "--force", help="Skip confirmation"),
):
    """Delete a web app."""
    try:
        account, client = get_client(WebappsClient)
        if not force:
            confirm = typer.confirm(f"Are you sure you want to delete {domain_name}?")
            if not confirm:
                typer.echo("Cancelled.")
                raise typer.Exit()
        client.delete(account["username"], domain_name)
        typer.echo(f"Webapp {domain_name} deleted.")
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Not found: {e}", err=True)
        raise typer.Exit(code=1)


@app.command()
def enable(
    domain_name: str = typer.Argument(..., help="Domain name"),
):
    """Enable a web app."""
    try:
        account = Config.load(verbose=True)
        crawler = AccountCrawler()
        crawler.login()
        if crawler.enable_webapp(domain_name):
            typer.echo(f"Webapp {domain_name} enabled.")
        else:
            typer.echo(f"Failed to enable webapp {domain_name}.", err=True)
            raise typer.Exit(code=1)
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Not found: {e}", err=True)
        raise typer.Exit(code=1)


@app.command()
def disable(
    domain_name: str = typer.Argument(..., help="Domain name"),
):
    """Disable a web app."""
    try:
        account = Config.load(verbose=True)
        crawler = AccountCrawler()
        crawler.login()
        if crawler.disable_webapp(domain_name):
            typer.echo(f"Webapp {domain_name} disabled.")
        else:
            typer.echo(f"Failed to disable webapp {domain_name}.", err=True)
            raise typer.Exit(code=1)
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Not found: {e}", err=True)
        raise typer.Exit(code=1)


@app.command()
def logs(
    domain_name: str = typer.Argument(None, help="Domain name (default: {username}.pythonanywhere.com)"),
    log_type: str = typer.Option("error", "--type", "-t", help="Log type: access, error, or server"),
    lines: int = typer.Option(50, "--lines", "-n", help="Number of lines to show"),
):
    """Show web app logs."""
    try:
        account, client = get_client(FilesClient)
        if domain_name is None:
            domain_name = f"{account['username']}.pythonanywhere.com"

        # Extract subdomain from domain_name (lowercase)
        subdomain = domain_name.split(".")[0].lower()
        log_file = f"/var/log/{subdomain}.pythonanywhere.com.{log_type}.log"

        try:
            content = client.download(account["username"], log_file)
            text = content.decode("utf-8", errors="ignore")
            # Show last N lines
            all_lines = text.strip().split("\n")
            for line in all_lines[-lines:]:
                typer.echo(line)
        except NotFoundError:
            typer.echo(f"Log file not found: {log_file}", err=True)
            raise typer.Exit(code=1)
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Not found: {e}", err=True)
        raise typer.Exit(code=1)


@app.command()
def ssl(
    domain_name: str = typer.Argument(None, help="Domain name (default: {username}.pythonanywhere.com)"),
):
    """Show SSL certificate information."""
    try:
        account, client = get_client(WebappsClient)
        if domain_name is None:
            domain_name = f"{account['username']}.pythonanywhere.com"
        data = client.get_ssl_info(account["username"], domain_name)
        cert_type = data.get("cert_type", "N/A")
        typer.echo(f"SSL Certificate Info for {domain_name}:")
        typer.echo(f"  Type: {cert_type}")
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Not found: {e}", err=True)
        raise typer.Exit(code=1)


@app.command("default-python")
def default_python(
    version: str = typer.Argument(None, help="Python version to set (e.g. python310, python311)"),
):
    """Get or set default Python 3 version."""
    try:
        account, client = get_client(WebappsClient)
        if version:
            client.set_default_python3_version(account["username"], version)
            typer.echo(f"Default Python version set to {version}")
        else:
            data = client.get_default_python3_version(account["username"])
            current = data.get("version", "N/A")
            available = data.get("available_versions", [])
            typer.echo(f"Current default Python version: {current}")
            if available:
                typer.echo(f"Available versions: {', '.join(available)}")
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Not found: {e}", err=True)
        raise typer.Exit(code=1)
    except APIError as e:
        typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(code=1)
