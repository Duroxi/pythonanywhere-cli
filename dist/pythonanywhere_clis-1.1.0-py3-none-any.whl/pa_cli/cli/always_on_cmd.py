import typer

from pa_cli.api.always_on import AlwaysOnClient
from pa_cli.cli.utils import get_client
from pa_cli.exceptions import AuthError, NetworkError, NotFoundError, APIError

app = typer.Typer(help="Manage always-on tasks on PythonAnywhere.")


@app.command("list")
def list_tasks():
    """List all always-on tasks."""
    try:
        account, client = get_client(AlwaysOnClient)
        tasks = client.list(account["username"])
        if not tasks:
            typer.echo("No always-on tasks found.")
            return
        for task in tasks:
            status = "enabled" if task.get("enabled") else "disabled"
            typer.echo(f"ID: {task['id']}, Command: {task['command']}, Status: {status}")
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except APIError as e:
        typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(code=1)


@app.command()
def create(
    command: str = typer.Argument(..., help="Command to run"),
):
    """Create a new always-on task."""
    try:
        account, client = get_client(AlwaysOnClient)
        task = client.create(account["username"], command=command)
        typer.echo(f"Always-on task created: ID={task['id']}, Command={task['command']}")
    except APIError as e:
        if "limit" in str(e).lower():
            typer.echo("Error: Always-on task limit reached. Upgrade your plan to add more.", err=True)
        else:
            typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(code=1)
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)


@app.command()
def delete(
    task_id: int = typer.Argument(..., help="Task ID to delete"),
    force: bool = typer.Option(False, "-f", "--force", help="Skip confirmation"),
):
    """Delete an always-on task."""
    try:
        account, client = get_client(AlwaysOnClient)
        if not force:
            confirm = typer.confirm(f"Are you sure you want to delete always-on task {task_id}?")
            if not confirm:
                typer.echo("Cancelled.")
                raise typer.Exit()
        client.delete(account["username"], task_id)
        typer.echo(f"Always-on task {task_id} deleted.")
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Task not found: {e}", err=True)
        raise typer.Exit(code=1)
    except APIError as e:
        typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(code=1)


@app.command()
def update(
    task_id: int = typer.Argument(..., help="Task ID to update"),
    command: str = typer.Option(None, "--command", "-c", help="New command"),
    description: str = typer.Option(None, "--description", "-d", help="New description"),
    enabled: bool = typer.Option(None, "--enabled/--disabled", "-e/-E", help="Enable or disable task"),
):
    """Update an always-on task."""
    try:
        account, client = get_client(AlwaysOnClient)
        kwargs = {}
        if command is not None:
            kwargs["command"] = command
        if description is not None:
            kwargs["description"] = description
        if enabled is not None:
            kwargs["enabled"] = enabled
        if not kwargs:
            typer.echo("Error: No update specified. Use --command, --description, or --enabled/--disabled.", err=True)
            raise typer.Exit(code=1)
        client.update(account["username"], task_id, **kwargs)
        typer.echo(f"Always-on task {task_id} updated.")
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Task not found: {e}", err=True)
        raise typer.Exit(code=1)
    except APIError as e:
        typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(code=1)


@app.command()
def restart(
    task_id: int = typer.Argument(..., help="Task ID to restart"),
):
    """Restart an always-on task."""
    try:
        account, client = get_client(AlwaysOnClient)
        client.restart(account["username"], task_id)
        typer.echo(f"Always-on task {task_id} restarted.")
    except AuthError as e:
        typer.echo(f"Auth error: {e}", err=True)
        raise typer.Exit(code=1)
    except NetworkError as e:
        typer.echo(f"Network error: {e}", err=True)
        raise typer.Exit(code=1)
    except NotFoundError as e:
        typer.echo(f"Task not found: {e}", err=True)
        raise typer.Exit(code=1)
    except APIError as e:
        typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(code=1)
